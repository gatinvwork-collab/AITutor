"""Bounded native import. Originals are separately encrypted inside the vault."""

import io
import zipfile
from pathlib import Path

from .crypto import seal
from .errors import require
from .service import identity, now

MAX_FILE = 8 * 1024 * 1024


def import_file(service, path):
    service.user("STUDENT")
    path = Path(path)
    require(path.is_file() and path.stat().st_size <= MAX_FILE, "Файл должен быть не больше 8 МБ.")
    raw = path.read_bytes()
    ext = path.suffix.lower()
    text, warning = "", ""
    if ext in (".txt", ".py", ".csv"):
        text = raw.decode("utf-8-sig", errors="replace")[:30000]
    elif ext == ".pdf":
        require(raw.startswith(b"%PDF-"), "Это не PDF-файл.")
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(raw))
        require(not reader.is_encrypted and len(reader.pages) <= 30, "PDF: не более 30 страниц, без пароля.")
        text = "\n".join((p.extract_text() or "")[:5000] for p in reader.pages)[:30000]
        warning = "Проверьте формулы, таблицы и рисунки по оригиналу. Текстовое извлечение может их потерять."
    elif ext == ".docx":
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            require(sum(i.file_size for i in archive.infolist()) <= 32 * 1024 * 1024
                    and len(archive.infolist()) <= 500, "Документ слишком велик после распаковки.")
        from docx import Document
        document = Document(io.BytesIO(raw))
        parts = [p.text for p in document.paragraphs]
        parts += [" | ".join(c.text for c in row.cells) for table in document.tables for row in table.rows]
        text = "\n".join(parts)[:30000]
        warning = "Проверьте распознанный текст. Изображения и формулы требуют ручного подтверждения."
    elif ext in (".png", ".jpg", ".jpeg", ".webp"):
        from PySide6.QtGui import QImage
        image = QImage.fromData(raw)
        require(not image.isNull() and image.width() * image.height() <= 25_000_000,
                "Изображение повреждено или превышает 25 мегапикселей.")
        warning = "Автоматическое OCR ещё не подключено. Перепишите условие и решение, затем подтвердите текст."
    else:
        require(False, "Поддерживаются TXT, PY, CSV, PDF, DOCX, PNG, JPG и WEBP.")
    hid = identity()
    record = {"id": hid, "student": service.actor, "created": now(), "filename": path.name,
              "text": text, "confirmed": False, "warning": warning,
              "original": seal(service.store.attachment_key(), raw, hid.encode())}
    with service.store.transaction():
        service.store.put("homework", hid, record, service.actor)
    return {k: v for k, v in record.items() if k != "original"}
